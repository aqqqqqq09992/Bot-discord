module.exports = {
    bot: {
        token: '', // هنا تومن بوتك
        owners: ["", ""], // مو لازم
        mongourl: "mongodb+srv://jj0391566:salah99910@cluster0.es8gk.mongodb.net/", // هنا رابط داتا بيس
        callbackUrl: "http:///callback", //  /callback    //  لا تنسى تحط رابط في بوت رابط كول باك لا تنسى دول كلمات
        clientSecret: "", // هنا سيكريت بوت
        clientId: "" // هنا ايدي بوتك

    },
}
