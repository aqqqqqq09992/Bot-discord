const { Client, Collection, GatewayIntentBits } = require("discord.js");

const Discord = require("discord.js");

const express = require("express");

const session = require("express-session");

const passport = require("passport");

const { Strategy } = require("passport-discord");

const mongoose = require("mongoose");

const fs = require("fs");

// إعدادات الخادم والبوت

const client = new Discord.Client({ intents: Object.keys(GatewayIntentBits) });

const app = express();

const config = require("./config.js");

// إعداد EJS

app.set("view engine", "ejs");

app.set("views", "./views");

// Middleware

app.use(express.json());

app.use(express.urlencoded({ extended: true }));

app.use(express.static("public"));

// إعداد الجلسة

app.use(session({

    secret: "super-secret-key",

    resave: false,

    saveUninitialized: false,

}));

// إعداد Passport

passport.use(new Strategy({

    clientID: config.bot.clientId,

    clientSecret: config.bot.clientSecret,

    callbackURL: config.bot.callbackUrl,

    scope: ["identify", "guilds"]

}, (accessToken, refreshToken, profile, done) => {

    return done(null, profile);

}));

passport.serializeUser((user, done) => done(null, user));

passport.deserializeUser((obj, done) => done(null, obj));

app.use(passport.initialize());

app.use(passport.session());

// اتصال قاعدة البيانات

mongoose.connect(config.bot.mongourl, { useNewUrlParser: true, useUnifiedTopology: true })

    .then(() => console.log("Database connected"))

    .catch(err => console.error("Database connection error:", err));

// نماذج قاعدة البيانات

const Profile = require("/home/container/Database/models/Profile.js");

const Balance = require("/home/container/Database/models/coins.js");

const Transfer = require("/home/container/Database/models/transfer.js");

// تسجيل الدخول

app.get("/login", passport.authenticate("discord"));

app.get("/callback", passport.authenticate("discord", { failureRedirect: "/" }), (req, res) => {

    res.redirect("/dashboard");

});

// تسجيل الخروج

app.get("/logout", (req, res) => {

    req.logout(err => {

        if (err) console.error(err);

        res.redirect("/");

    });

});

// الصفحة الرئيسية

app.get("/", (req, res) => {

    res.render("index", { user: req.user });

});

// لوحة التحكم

app.get("/dashboard", async (req, res) => {

    if (!req.isAuthenticated()) return res.redirect("/login");

    const userId = req.user.id;

    try {

        const balance = await Balance.findOne({ userId }) || new Balance({ userId, balance: 0 });

        res.render("dashboard", {

            user: req.user,

            balance: balance.balance,

        });

    } catch (err) {

        console.error(err);

        res.status(500).send("An error occurred.");

    }

});

// صفحة المتجر

app.get("/store", async (req, res) => {

    if (!req.isAuthenticated()) return res.redirect("/login");

    const userId = req.user.id;

    try {

        const profile = await Profile.findOne({ userID: userId }) || new Profile({ userID: userId });

        const balance = await Balance.findOne({ userId }) || new Balance({ userId });

        const backgrounds = [

            { id: "bg1", name: "صوره كلب الرايق", price: 1, image: "https://cdn.discordapp.com/attachments/1306600425834680352/1312348326846398464/Screenshot_-.jpg?ex=674c2b1f&is=674ad99f&hm=50d2bdc3135cd75a333b50da54d5176a304ad753d1967f7b4bec9d82c2472623&" },
            { id: "bg2", name: "عدم استسلم", price: 1, image: "https://cdn.discordapp.com/attachments/1306600425834680352/1312348372191023134/Screenshot_-.jpg?ex=674c2b2a&is=674ad9aa&hm=20dfd91997d34d9382323959d16075df987b2caaf06bb2d7b11da7d2db3e30c9&" },
//{ id: " bg بترتيب ارقام الي فوق حط", name: "اسم صوره", price: سعر, image: "رابط صوره" },
            { id: "bg3", name: "صوره تشجيع", price: 2, image: "https://cdn.discordapp.com/attachments/1306600425834680352/1312348402289213510/Screenshot_-.jpg?ex=674c2b31&is=674ad9b1&hm=dda4798342a6115e254ec33b9ee0df1469fc89f89384fe19ddf7096c732b4bd3&" },

        ];

        res.render("store", {

            user: req.user,

            balance: balance.balance,

            currentBackground: profile.currentBackground,

            backgrounds,

        });

    } catch (err) {

        console.error(err);

        res.status(500).send("An error occurred.");

    }

});

// شراء الخلفيات

app.post("/buy", async (req, res) => {

    if (!req.isAuthenticated()) return res.redirect("/login");

    const userId = req.user.id;

    const { backgroundId } = req.body;

    try {

        const profile = await Profile.findOne({ userID: userId }) || new Profile({ userID: userId });

        const balance = await Balance.findOne({ userId }) || new Balance({ userId });

        const backgrounds = {

            bg1: { price: 1, image: "https://cdn.discordapp.com/attachments/1306600425834680352/1312348326846398464/Screenshot_-.jpg?ex=674c2b1f&is=674ad99f&hm=50d2bdc3135cd75a333b50da54d5176a304ad753d1967f7b4bec9d82c2472623&" },

            bg2: { price: 1, image: "https://cdn.discordapp.com/attachments/1306600425834680352/1312348372191023134/Screenshot_-.jpg?ex=674c2b2a&is=674ad9aa&hm=20dfd91997d34d9382323959d16075df987b2caaf06bb2d7b11da7d2db3e30c9&" },
            bg3: { price: 1, image: "https://cdn.discordapp.com/attachments/1306600425834680352/1312348402289213510/Screenshot_-.jpg?ex=674c2b31&is=674ad9b1&hm=dda4798342a6115e254ec33b9ee0df1469fc89f89384fe19ddf7096c732b4bd3&" },
            // bgزود رقم : { price: سعر, image: "رابط صوره" },

        };

        const selectedBackground = backgrounds[backgroundId];

        if (!selectedBackground) return res.status(400).send("Invalid background.");

        if (balance.balance < selectedBackground.price) return res.status(400).send("Insufficient balance.");

        balance.balance -= selectedBackground.price;

        profile.currentBackground = selectedBackground.image;

        await balance.save();

        await profile.save();

        res.redirect("/store");

    } catch (err) {

        console.error(err);

        res.status(500).send("An error occurred.");

    }

});

// عرض سجلات التحويلات

app.get("/transfers", async (req, res) => {

    if (!req.isAuthenticated()) return res.redirect("/login");

    const userId = req.user.id;

    try {

        const transfers = await Transfer.find({ receiverId: userId }).sort({ timestamp: -1 });

        res.render("transfers", {

            user: req.user,

            transfers,

        });

    } catch (err) {

        console.error(err);

        res.status(500).send("An error occurred.");

    }

});


app.get("/daily", async (req, res) => {

  if (!req.isAuthenticated()) return res.redirect("/login");
     
const userId = req.user.id;

  const timeout = 86400000; // 24 ساعة

  const randomNumber = Math.floor(Math.random() * 9000) + 1000; // رقم عشوائي من 4 أرقام

  let userBalance = await Balance.findOne({ userId });
          if (!userBalance) {

    userBalance = new Balance({

      userId,

      balance: 0,

      lastClaim: null,

    });

    await userBalance.save();

  }
let timeRemaining = null;

  if (userBalance.lastClaim && Date.now() - userBalance.lastClaim < timeout) {

    timeRemaining = timeout - (Date.now() - userBalance.lastClaim);

  }

  res.render("daily", {

    user: req.user,

    randomNumber,

    timeRemaining,

  });

});
        app.post("/daily", async (req, res) => {

  if (!req.isAuthenticated()) return res.redirect("/login");

  const userId = req.user.id;

  const timeout = 86400000;

  const { enteredNumber, generatedNumber } = req.body;
const amount = Math.floor(Math.random() * (1200 - 800 + 1)) + 800; // من 800 إلى 1200 عملة

  let userBalance = await Balance.findOne({ userId });

  if (!userBalance) {

    userBalance = new Balance({

      userId,

      balance: 0,

      lastClaim: null,

    });
            await userBalance.save();

  }

  if (userBalance.lastClaim && Date.now() - userBalance.lastClaim < timeout) {

    return res.status(400).send("You have already claimed your daily reward.");

  }

            if (parseInt(enteredNumber) === parseInt(generatedNumber)) {

    userBalance.balance += amount;

    userBalance.lastClaim = Date.now();

    await userBalance.save();

    res.send(`You have received ${amount} coins!`);

  } else {

    res.status(400).send("Incorrect number entered.");

  }

});

            
// تشغيل الخادم

const PORT = 21838; // حط بورت استضافة هنا

app.listen(PORT, () => {

    console.log(`Server running on http://localhost:${PORT}`);

});

// تشغيل البوت

client.SlashCommands = new Collection();

fs.readdirSync("./handlers").forEach(handler => {

    require(`./handlers/${handler}`)(client);

});

// أخطاء

process.on("unhandledRejection", (reason, p) => console.log(reason));

process.on("uncaughtException", (err, origin) => console.log(err));

client.login(config.bot.token);